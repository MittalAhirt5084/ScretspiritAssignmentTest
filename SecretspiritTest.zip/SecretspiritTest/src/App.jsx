import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from './Components/Loginpage/LoginPage';
import HomePage from './Components/HomePage/HomePage';
import Grid from './Components/Grid/Grid';

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/homepage" element={<HomePage />} />
        <Route path="/grid" element={<Grid />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App;
