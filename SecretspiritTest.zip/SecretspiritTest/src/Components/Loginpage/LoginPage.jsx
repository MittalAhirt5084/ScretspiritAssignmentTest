import React, { useState } from "react";
import "./LoginPage.css";
import TextField from "@mui/material/TextField";
import { Link } from "react-router-dom";
import Button from "@mui/material/Button";
import Logo from "../Images/logo.png";
import { FaFacebookF } from "react-icons/fa";
import { FcGoogle } from "react-icons/fc";
import { useNavigate } from "react-router-dom";

const SignIn = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSignIn = (e) => {
    e.preventDefault();

    if (email === "mittal@1084.com" && password === "mittal1084") {
      setError("");
      navigate("/homepage");
    } else {
      setError("Invalid email or password. Please try again.");
    }
  };
  const isFormFilled = email.trim() !== "" && password.trim() !== "";

  return (
    <div className="container-fluid vh-100 d-flex align-items-center">
      <div className="row">
        <div className="col-md-6 p-5">
          <div className="logo">
            <h3 className="fw-bold">
              <img
                src={Logo}
                alt="Makemymarry"
                className="me-1"
                style={{ width: "60px" }}
              />
              Makemymarry
            </h3>
          </div>

          <h2
            className="fw-bold"
            style={{ width: "70%", whiteSpace: "normal" }}
          >
            Sign in to find your perfect partner
          </h2>
          <p className="text-muted" style={{ fontWeight: 450 }}>
            Enter email address and password or use Google or Facebook account
            or via OTP to login to your account.
          </p>
          <form onSubmit={handleSignIn}>
            <div className="mb-3">
              <label htmlFor="email" className="form-label">
                Email <span className="text-danger">*</span>
              </label>
              <TextField
                id="email"
                variant="filled"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                fullWidth
              />
            </div>
            <div className="mb-3">
              <label htmlFor="password" className="form-label">
                Password <span className="text-danger">*</span>
              </label>
              <TextField
                id="password"
                variant="filled"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                fullWidth
              />
            </div>
            {error && <div className="text-danger mb-3">{error}</div>}

            <div className="d-flex justify-content-between align-items-center">
              <Link
                href="#forgot-password"
                className="text small"
                style={{
                  color: "#c65b73df",
                  marginLeft: "26.8rem",
                  textDecoration: "none",
                }}
              >
                Forgot Password?
              </Link>
            </div>

            <Button
              type="submit"
              variant="contained"
              fullWidth
              sx={{
                mt: 3,
                backgroundColor: isFormFilled
                  ? "#df1b53"
                  : "rgba(0, 0, 0, 0.06)",
                color: isFormFilled ? "white" : "darkGrey",
                transition: "0.3s ease-in-out",
              }}
              disabled={!isFormFilled}
            >
              Sign in
            </Button>
          </form>

          <div className="d-flex align-items-center mt-3">
            <hr
              className="flex-grow-1"
              style={{ borderTop: "2px solid #ccc" }}
            />
            <span className="mx-3">OR</span>
            <hr
              className="flex-grow-1"
              style={{ borderTop: "2px solid #ccc" }}
            />
          </div>

          <div
            className="d-flex justify-content-center mt-3 px-4"
            style={{ gap: "4vw" }}
          >
            <button
              className="btn btn-outline-dark d-flex justify-content-center align-items-center gap-2 fw-bold"
              style={{ width: "200px", height: "50px" }}
            >
              <FaFacebookF style={{ color: "#4267B2", fontSize: "1.5rem" }} />{" "}
              Facebook
            </button>

            <button
              className="btn btn-outline-dark d-flex justify-content-center align-items-center gap-2 fw-bold"
              style={{ width: "200px", height: "50px" }}
            >
              <FcGoogle style={{ fontSize: "1.5rem" }} /> Google
            </button>

            <button
              className="btn d-flex justify-content-center align-items-center "
              style={{
                width: "200px",
                height: "50px",
                background:
                  "linear-gradient(90deg, rgba(235, 91, 132, 1) 0%, rgba(201, 24, 74, 1) 100%)",
                color: "#fff",
              }}
            >
              Connect via OTP
            </button>
          </div>

          <hr
            className="flex-grow-1 m-4"
            style={{ borderTop: "2px solid #ccc" }}
          />

          <p className="text-center mt-4" style={{ marginLeft: "20rem" }}>
            New to Makemymarry?{" "}
            <Link
              href="#signup"
              className="text"
              style={{ color: "#c65b73df", textDecoration: "none" }}
            >
              Sign Up
            </Link>
          </p>
        </div>

        <div
          className="col-md-6 d-flex align-items-center justify-content-center bg-gradient"
          style={{ backgroundColor: "#df1b53" }}
        >
          <div className="text-center text-white">
            <h2>This is an onboarding screen 1</h2>
            <p>
              Talk about one of the features of your application & how it will
              help your users.
            </p>
            <div className="dots">
              <span className="dot"></span>
              <span className="middledot"></span>
              <span className="dot"></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignIn;
